import math


def eratostenes(liczba):
    numbers = []
    tab = []
    for x in range(liczba - 1):
        tab.append(True)

    for i in range(2, int(math.sqrt(liczba))):
        if tab[i-2]:
            for j in range(2*i, liczba + 1, i):
                tab[j-2] = False

    for i in range(len(tab)):
        if (tab[i]):
            numbers.append(i+2)
    return numbers


n = 200
print(eratostenes(n))
